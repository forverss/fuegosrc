/** @format
 *
 * Fuego By Painfuego
 * Version: 6.0.0-beta
 * © 2024 1sT-Services
 */

module.exports = {
  //commands/config/247
  247: {
    247: "<:247:1187282249993961513>",
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    off: "<:ndisable:1232017186089078864>",
    on: "<:nenable:1232017196557795410>",
  },
  //commands/config/buy
  buy: {
    bell: "<:eg_notification:1248897505773752422>",
    coin: "<a:blue_2077:1169202393037144064>",
    cool: "<:uptime:1222281805940392067>",
    danger: "<:danger:1188879968453800058>",
    free: "<:free:1188879687590608896>",
    no: "<:nwrong:1222291009073971326>",
    on: "<:nenable:1232017196557795410>",
    point: "<a:reddot_:1068187517528068126>",
    premium: "<:diamond:1188879476776517673>",
    rich: "<:nitro:1188879849591406723>",
    warn: "<:warn:1187279948449337384>",
  },

  //commands/config/config
  config: {
    cog: "<:nsetting:1222077486544846971>",
    off: "<:ndisable:1232017186089078864>",
    on: "<:nenable:1232017196557795410>",
    point: "<a:reddot_:1068187517528068126>",
  },

  //commands/config/ignore
  ignore: {
    cog: "<:nsetting:1222077486544846971>",
    rem: "<:ndisable:1232017186089078864>",
    add: "<:nenable:1232017196557795410>",
    point: "<a:reddot_:1068187517528068126>",
    no: "<:nwrong:1222291009073971326>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/config/premium
  premium: {
    admin: "<:blackrole:1185820599088582756>",
    bell: "<:eg_notification:1248897505773752422>",
    free: "<:free:1188879687590608896>",
    rich: "<:nitro:1188879849591406723>",
    danger: "<:danger:1188879968453800058>",
    diamond: "<:diamond:1188879476776517673>",
  },

  //commands/config/prefix
  prefix: {
    bell: "<:eg_notification:1248897505773752422>",
    cog: "<:nsetting:1222077486544846971>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/config/preset
  preset: {
    cog: "<:nsetting:1222077486544846971>",
    no: "<:nwrong:1222291009073971326>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/config/profile
  profile: {
    coin: "<:black_moeda_2:1185821294856515667>",
    dev: "<:developer:1188921403005751436>",
    admin: "<:admin:1188921396932378665>",
    premium: "<:premium:1188879476776517673>",
    user: "<:users:1188921543170990181>",
  },

  //commands/config/redeem
  redeem: {
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    on: "<:nenable:1232017196557795410>",
    point: "<a:reddot_:1068187517528068126>",
    premium: "<:premium:1188879476776517673>",
  },

  /////////////////////////////////////////////////////

  //commands/filter/filter
  enhance: {
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  optimize: {
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/filter/filter
  equalizer: {
    bell: "<:eg_notification:1248897505773752422>",
    cog: "<:nsetting:1222077486544846971>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/filter/equalizer
  filter: {
    cog: "<:nsetting:1222077486544846971>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  /////////////////////////////////////////////////////

  //commands/information/balance
  balance: {
    coin: "<:coin:1188384481736929301>",
    danger: "<:danger:1188879968453800058>",
    free: "<:free:1188879687590608896>",
    rich: "<:nitro:1188879849591406723>",
  },

  //commands/information/help
  help: {
    arrow: "<:arrow_2077:1248896042414379018>",
    no: "<:nwrong:1222291009073971326>",
    point: "<a:reddot_:1068187517528068126>",
    home: "<:eg_home:1248897422889975941>",
    music: "<:nmusic:1222077221200465944>",
    config: "<:eg_wrench:1243486966629142570>",
    filter: "<:eg_fire:1248896978192957541>",
    information: "<:nquestion:1248894230886223902>",
    all: "<:ndevelopers:1222290414866923702>",
  },

  //commands/information/info
  info: {
    ver: "<:cog:1187274696530612284>",
    web: "<:web:1192369694817124393>",
    partner: "<:partner:1192368654122225685>",
    verified: "<:verified:1192368662477287505>",
    nodejs: "<:nodejs:1192365812389007501>",
    djs: "<:discordjs:1192365805007028244>",
    link: "<:link:1189089242605965373>",
    cog: "<:cog:1187274696530612284>",
    dev: "<:developer:1188921403005751436>",
    admin: "<:admin:1188921396932378665>",
    king: "<:owner:1191113639965491260>",
    no: "<:black_wrong:1185819723947069492>",
    dir: "<:dir:1189088959544967238>",
    lines: "<:line:1187277316154466346>",
  },

  //commands/information/invite
  invite: {
    bell: "<:eg_notification:1248897505773752422>",
  },

  //commands/information/notice
  notice: {
    no: "<:nwrong:1222291009073971326>",
    yes: "<:tick_icon:1249756052464078858>",
    bug: "<:bug:1189086333617049720>",
  },

  //commands/information/ping
  ping: {
    link: "<:link:1189089242605965373>",
    cool: "<:uptime:1222281805940392067>",
    message: "<:message:1188911512555880588>",
    data: "<:dir:1189088959544967238>",
    node: "<:connect:1189088206734504018>",
  },

  //commands/information/report
  report: {
    bell: "<:eg_notification:1248897505773752422>",
    bug: "<:bug:1189086333617049720>",
    danger: "<:danger:1188879968453800058>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/information/stats
  stats: {
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/information/support
  support: {
    support: "<:supportteam:1189089913031897118>",
  },

  //commands/information/vote
  vote: {
    vote: "<:vote:1189093111033512008>",
  },

  /////////////////////////////////////////////////////

  //commands/music/autoplay
  autoplay: {
    autoplay: "<:autoplay:1190175852084867195>",
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    off: "<:ndisable:1232017186089078864>",
    on: "<:nenable:1232017196557795410>",
  },

  //commands/music/clear
  clear: {
    bell: "<:eg_notification:1248897505773752422>",
    cog: "<:nsetting:1222077486544846971>",
    list: "<:queue:1190178668195102800>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/music/grab
  grab: {
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
    cool: "<:uptime:1222281805940392067>",
    user: "<:users:1188921543170990181>",
  },

  //commands/music/join
  join: {
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    on: "<:nenable:1232017196557795410>",
    warn: "<:warn:1187279948449337384>",
  },

  //commands/music/leave
  leave: {
    cool: "<:uptime:1222281805940392067>",
    off: "<:ndisable:1232017186089078864>",
  },

  rejoin: {
    cool: "<:uptime:1222281805940392067>",
    on: "<:nenable:1232017196557795410>",
  },

  //commands/music/loop
  loop: {
    loop: "<:loop:1191054855838650529>",
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    on: "<:nenable:1232017196557795410>",
    off: "<:ndisable:1232017186089078864>",
    no: "<:black_wrong:1185819723947069492>",
    queue: "<:queue:1190178668195102800>",
    track: "<:nmusic:1222077221200465944>",
  },

  //commands/music/nowPlaying
  nowplaying: {},

  //commands/music/pause
  pause: {
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/music/play
  play: {
    bell: "<:eg_notification:1248897505773752422>",
    warn: "<:warn:1187279948449337384>",
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
    search: "<:search:1191095442503647403>",
  },

  //commands/music/previous
  previous: {
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/music/queue
  queue: {
    cool: "<:uptime:1222281805940392067>",
  },

  //commands/music/radio
  radio: {
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    radio: "<:radio:1189097687883198464>",
    support: "<:support:1189089913031897118>",
    warn: "<:warn:1187279948449337384>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/music/remove
  remove: {
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/music/resume
  resume: {
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/music/search
  search: {
    yes: "<:tick_icon:1249756052464078858>",
    warn: "<:warn:1187279948449337384>",
    no: "<:nwrong:1222291009073971326>",
    youtube: "<:youtube:1192367807137054771>",
    soundcloud: "<:soundcloud:1191086834575487026>",
    spotify: "<:spotify:1191086714094096485>",
    search: "<:search:1191095442503647403>",
    track: "<:nmusic:1222077221200465944>",
  },

  //commands/music/seek
  seek: {
    bell: "<:eg_notification:1248897505773752422>",
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/music/shuffle
  shuffle: {
    yes: "<:tick_icon:1249756052464078858>",
  },

  similar: {
    yes: "<:tick_icon:1249756052464078858>",
    warn: "<:warn:1187279948449337384>",
    no: "<:nwrong:1222291009073971326>",
    youtube: "<:youtube:1192367807137054771>",
    soundcloud: "<:soundcloud:1191086834575487026>",
    spotify: "<:spotify:1191086714094096485>",
    search: "<:search:1191095442503647403>",
    track: "<:nmusic:1222077221200465944>",
  },

  //commands/music/skip
  skip: {
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/music/stop
  stop: {
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/music/volume
  volume: {
    bell: "<:volumeee2:1191108378232098867>",
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  /////////////////////////////////////////////////////

  //commands/owner/add
  add: {
    admin: "<:admin:1188921396932378665>",
    bell: "<:eg_notification:1248897505773752422>",
    no: "<:nwrong:1222291009073971326>",
    on: "<:nenable:1232017196557795410>",
    user: "<:users:1188921543170990181>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/owner/backup
  backup: {
    cool: "<:uptime:1222281805940392067>",
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/owner/coin
  coin: {
    coin: "<:coin:1188384481736929301>",
    yes: "<:tick_icon:1249756052464078858>",
    no: "<:nwrong:1222291009073971326>",
  },

  //commands/owner/list
  list: {
    bell: "<:eg_notification:1248897505773752422>",
    no: "<:nwrong:1222291009073971326>",
    cool: "<:uptime:1222281805940392067>",
    user: "<:users:1188921543170990181>",
    list: "<:list:1187277316154466346>",
  },

  //commands/owner/panel
  panel: {
    cool: "<:uptime:1222281805940392067>",
  },

  //commands/owner/pi
  pi: {},

  //commands/owner/reload
  reload: {},

  //commands/owner/restart
  restart: {
    bell: "<:eg_notification:1248897505773752422>",
    cool: "<:uptime:1222281805940392067>",
    no: "<:nwrong:1222291009073971326>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  //commands/owner/revoke
  revoke: {
    admin: "<:admin:1188921396932378665>",
    bell: "<:eg_notification:1248897505773752422>",
    no: "<:nwrong:1222291009073971326>",
    on: "<:nenable:1232017196557795410>",
    off: "<:ndisable:1232017186089078864>",
    user: "<:users:1188921543170990181>",
    yes: "<:tick_icon:1249756052464078858>",
  },

  /////////////////////////////////////////////////////

  //stat cmd (bcevl + global)
  cog: "<:nsetting:1222077486544846971>",
  free: "<:free:1188879687590608896>",
  user: "<:users:1188921543170990181>",

  //global
  point: "<a:reddot_:1068187517528068126>",
  king: "<:owner:1191113639965491260>",
  bell: "<:eg_notification:1248897505773752422>",
  cool: "<:uptime:1222281805940392067>",
  warn: "<:warn:1187279948449337384>",
  yes: "<:tick_icon:1249756052464078858>",
  no: "<:nwrong:1222291009073971326>",
  helpline: "<:support:1189089913031897118>",
  message: "<:message:1188911512555880588>",
  free: "<:free:1188879687590608896>",
  new: "<:newMember:1191111740231004243>",
  admin: "<:admin:1188921396932378665>",
  rad: "<:radio:1189097687883198464>",
  diamond: "<:diamond:1191112574666809374>",
};
